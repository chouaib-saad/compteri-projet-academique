package com.example.myapplication.Utility;

public interface ISharedPreference {


    String get(String name);

    void put (String name,String value);


}
