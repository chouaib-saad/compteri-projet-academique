package com.example.myapplication;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.example.myapplication.Utility.NetworkChangeListener;
import com.example.myapplication.control_fragments.Living_Room_Frag;
import com.example.myapplication.main_fragments.Control;
import com.example.myapplication.main_fragments.Settings;
import com.example.myapplication.main_fragments.Stats;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import me.ibrahimsn.lib.OnItemSelectedListener;
import me.ibrahimsn.lib.SmoothBottomBar;
import mqtt.server.Connection;
import mqtt.server.Message;
import mqtt.server.Subscription;
import soup.neumorphism.NeumorphCardView;

public class SmartHome_Main extends AppCompatActivity implements MqttCallback {


    NetworkChangeListener networkChangeListener = new NetworkChangeListener();

//    public DataClass dataClass ;
private MqttAndroidClient mClient;


    //bottomBar
    SmoothBottomBar bottomBar;
//    BottomNavigationView bottom_navigation;

    //inisialise fragments
    Control control = new Control();
    Stats stats = new Stats();
    Settings settings = new Settings();

    public static NeumorphCardView progressBar;


    //set user Informationsj
    TextView addresse, name, example3, example4, user_name;

    //profile image
    ImageView profil_image;




    @Override
    protected void onStop() {
        unregisterReceiver(networkChangeListener);
        super.onStop();
    }


    @Override
    protected void onRestart() {
        super.onRestart();
        startActivity(new Intent(SmartHome_Main.this, PinActivity.class));
//        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
        setTheUserData();
    }



    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkChangeListener,filter);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        super.onStart();
        setTheUserData();
    }



    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);




    }

    @Override
    public void onBackPressed() {
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.smart_home_main);

//        pour le moment
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        //progressbar hook;
        progressBar = findViewById(R.id.progress_bar_block);


        //profil components
        user_name = findViewById(R.id.user_name);
        profil_image = findViewById(R.id.profil_image);

        // ** set the first fragment as active **
//        replace(new Control());
//        getSupportFragmentManager().beginTransaction().setCustomAnimations(R.anim.fade_in,R.anim.fade_out).replace(R.id.frame,control).commit();
        getSupportFragmentManager().beginTransaction().replace(R.id.frame,control).commit();

        // ** make the bottom menu **
        bottomMenu();

        // ** set the user data **
        setTheUserData();


        init();








    }  // *** OnCreate end ***










    private void init() {
//
//        clientID = "xxx";
//        topic = "HomeLed/dataFromEsp";
////
//        client =
//                new MqttAndroidClient(this.getApplicationContext(), "tcp://192.168.0.8:1883",
//                        clientID);


                connectX();


    }


    private void connectX() {
        Connection connection = new Connection(getApplicationContext(), "192.168.137.1", Integer.parseInt("1883"), "old methode", "", "", false);
        connect(connection, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Log.d("ConnectionFragment", "Connected to: " + asyncActionToken.getClient().getServerURI());

                sub();


            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Toast.makeText(getApplicationContext(), exception.toString(), Toast.LENGTH_SHORT).show();
                exception.printStackTrace();
            }
        });



    }




    private void sub() {


        final Subscription subscription = new Subscription("compteur/coutMesuree",0);
        final String topic = "compteur/coutMesuree";
        subscribe(subscription, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Toast.makeText(getApplicationContext(), "Failed to subscribe", Toast.LENGTH_SHORT).show();

            }
        });

    }

    public void subscribe(Subscription subscription, IMqttActionListener listener) {
        if (notConnected(true)) {
            return;
        }
        try {
            mClient.subscribe(subscription.getTopic(), subscription.getQos(), null, listener);
        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to subscribe", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean notConnected(boolean showNotify) {
        if (mClient == null || !mClient.isConnected()) {
            if (showNotify) {
                Toast.makeText(this, "Client is not connected", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return false;
    }








    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {

        //important !!
//        Toast.makeText(this,"from activity othrer " + new String(message.getPayload()), Toast.LENGTH_SHORT).show();

        new Living_Room_Frag().updateMessage(new Message(topic, message));
//        MessageFragment.mAdapter.notifyDataSetChanged();



//        Message myMessage = new Message(topic,message);
//        MessageFragment.mList.add(myMessage);
//        MessageFragment.mAdapter.notifyDataSetChanged();
//        MessageFragment.mAdapter.notifyItemInserted(0);

    }



    //to delete
    public void connect(Connection connection, IMqttActionListener listener) {
        mClient = connection.getMqttAndroidClient(this);
        try {
            mClient.connect(connection.getMqttConnectOptions(), null, listener);
            mClient.setCallback(this);
        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to connect", Toast.LENGTH_SHORT).show();
        }

    }





    private void bottomMenu(){
        bottomBar = findViewById(R.id.bottomBar);
        bottomBar.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public boolean onItemSelect(int i) {
//                Fragment fragment = null;
                switch (i) {
                    case 0:
                        getSupportFragmentManager().beginTransaction().setCustomAnimations(R.anim.fade_in,R.anim.fade_out).replace(R.id.frame,control).commit();

//                        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction().setCustomAnimations(R.anim.fade_in,R.anim.fade_out);
//                        new Handler().postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                transaction.replace(R.id.frame,control).commit();
//                            }
//                        },200);
//                        fragment = control;
//                        replace(new Control());
                        return true;

                    case 1:
                        getSupportFragmentManager().beginTransaction().setCustomAnimations(R.anim.fade_in,R.anim.fade_out).replace(R.id.frame,stats).commit();

//                        replace(new Stats());
//                        fragment = stats;
                        return true;

                    case 2:
                        getSupportFragmentManager().beginTransaction().setCustomAnimations(R.anim.fade_in,R.anim.fade_out).replace(R.id.frame,settings).commit();
//                        fragment = settings;
//                        replace(new Settings());
                        return true;

                }
//                if(fragment != null){
//                    getSupportFragmentManager().beginTransaction().replace(R.id.frame,fragment).commit();
//                }
//                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,fragment).commit();
                  return false;
            }
        });

    }





//    private void replace(Fragment fragment) {
//
//        getSupportFragmentManager().beginTransaction().replace(R.id.frame,fragment).commit();
////        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
////        transaction.replace(R.id.frame,fragment);
////        transaction.commit();
//    }



    private void setTheUserData() {

        GoogleSignInAccount googleSignInAccount = GoogleSignIn.getLastSignedInAccount(SmartHome_Main.this);
        if (googleSignInAccount != null) {


            //set profil name
            user_name.setText("welcome " + googleSignInAccount.getFamilyName().toLowerCase());
            //set profil image
            String profil_photo_link = googleSignInAccount.getPhotoUrl().toString();
            Glide.with(this)
                    .load(profil_photo_link)
                    .placeholder(R.drawable.image_loader)
                    .into(profil_image);

        } else {

            String username = getIntent().getStringExtra("name");
            String phone = getIntent().getStringExtra("phoneNumber");

            user_name.setText("bienvenue " + username);
            profil_image.setImageDrawable(getResources().getDrawable(R.drawable.default_user_img));
            profil_image.setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.bgBlue));

        }

    }

    @Override
    public void connectionLost(Throwable cause) {

    }


    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }
}//class end