package com.example.myapplication.stats_fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import com.example.myapplication.R;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import mqtt.server.BaseFragment;
import mqtt.server.Message;
import mqtt.server.MessageRecyclerViewAdapter;


public class MessageFragment extends BaseFragment {

    private MessageRecyclerViewAdapter mAdapter;

    private List<Fragment> mFragmentList = new ArrayList<>();

    private List<Message> mList = new ArrayList<>();


    private Button sub_btn;
    private String topic,clientID;
    private static final String TAG = "MainActivity";
    private MqttAndroidClient client;



    public MessageFragment() {
        // Required empty public constructor
    }

    public static MessageFragment newInstance() {
        return new MessageFragment();
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.fragment_message_list;
    }


    @Override
    protected void setUpView(View view) {
        RecyclerView recyclerView = view.findViewById(R.id.message_list);
        recyclerView.addItemDecoration(new DividerItemDecoration(fragmentActivity, DividerItemDecoration.VERTICAL));
        mAdapter = new MessageRecyclerViewAdapter(mList);
        recyclerView.setAdapter(mAdapter);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_message_list, container, false);


        init(v);




        return v;
    }

    public void updateMessage(Message message) {
        mList.add(0, message);
        mAdapter.notifyItemInserted(0);
//        Toast.makeText(fragmentActivity, "list updated !", Toast.LENGTH_SHORT).show();

    }



    private void init(View v){

        sub_btn = v.findViewById(R.id.sub_btn);
        clientID = "xxx";
        topic = "HomeLed/dataFromEsp";

        client =
                new MqttAndroidClient(getContext(), "tcp://192.168.0.8:1883",
                        clientID);

        sub_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                connectX();

            }
        });
    }






    private void connectX() {
        try {
            IMqttToken token = client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    // We are connected
                    Log.d(TAG, "onSuccess");
                    sub();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    // Something went wrong e.g. connection timeout or firewall problems
                    Log.d(TAG, "onFailure");

                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

    }



    private void sub() {

        try {
            client.subscribe(topic,0);
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {

                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {

//                    Toast.makeText(getContext(), new String(message.getPayload()), Toast.LENGTH_LONG).show();
                    updateMessage(new Message(topic, message));
                    ((MessageFragment) mFragmentList.get(3)).updateMessage(new Message(topic, message));
                    newInstance().updateMessage(new Message(topic, message));
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {

                    //toast or log
                    Log.d(TAG, "delevery completed");



                }
            });
        }catch (MqttException e){

            Log.d(TAG, "error:failed to connect");

        }
    }




}