package com.example.myapplication.control_fragments;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.List;

import mqtt.server.Connection;
import mqtt.server.Publish;
import mqtt.server.Subscription;

public class Bedroom_Frag extends Fragment implements MqttCallback {



    private MqttAndroidClient mClient;
    private List<Subscription> mSubscriptionList = new ArrayList<>();

    //controle de spammers
    DatabaseReference mydb;
    ImageView detection_image;
    TextView title_detection;

    //switch text
    TextView switch_txt1 ;
    TextView switch_txt2 ;
    TextView switch_txt3 ;

//    SwitchCompat switch_btn1 ;
    SwitchCompat switch_btn2 ;
//    SwitchCompat switch_btn3 ;


//    //switch images
//    ImageView lampe_im;
    ImageView window_im;
//    ImageView aircond_im;

    //switches layout
//    LinearLayout lampe_circle;
//    LinearLayout window_circle;
//    LinearLayout aircond_circle;



                    //*** onCreate begin ***

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_bedroom, container, false);


        detection_image = v.findViewById(R.id.detection_image);
        title_detection = v.findViewById(R.id.title_detection);

        Connection connection = new Connection(getContext(),"192.168.137.1", Integer.parseInt("1883"),"13141516","","",false);
        connect(connection, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
//                Log.d("ConnectionFragment", "Connected to: " + asyncActionToken.getClient().getServerURI());
//                Toast.makeText(fragmentActivity,  "Connected to: " + asyncActionToken.getClient().getServerURI().toString(), Toast.LENGTH_SHORT).show()

//                subX();
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Toast.makeText(getContext(), exception.toString(), Toast.LENGTH_SHORT).show();
                exception.printStackTrace();
            }
        });




        mydb= FirebaseDatabase.getInstance().getReference().child("DetectionDesSpammeurs");
        try {

            mydb.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // This method is called once with the initial value and again
                    // whenever data at this location is updated.
                    String dataFromDB = dataSnapshot.child("detection").getValue().toString();

                    if(Integer.parseInt(dataFromDB) == 1 ){

                        title_detection.setText("il ya un intrus !");
                        title_detection.setTextColor(getResources().getColor(R.color.red));
                        detection_image.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.red));



                        show_Notification();



                        NotificationCompat.Builder mBuilder= new NotificationCompat.Builder(getContext());

                        Intent i = new Intent(getContext(), Bedroom_Frag.class);
                        PendingIntent pendingIntent= PendingIntent.getActivity(getContext(),0,i,0);

                        mBuilder.setAutoCancel(true);
                        mBuilder.setDefaults(NotificationCompat.DEFAULT_ALL);
                        mBuilder.setWhen(20000);
                        mBuilder.setTicker("Ticker");
                        mBuilder.setContentInfo("Info");
                        mBuilder.setContentIntent(pendingIntent);
                        mBuilder.setSmallIcon(R.drawable.ic_add);
                        mBuilder.setContentTitle("New notification title");
                        mBuilder.setContentText("Notification text");
                        mBuilder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));

                        NotificationManager notificationManager= (NotificationManager)getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                        notificationManager.notify(2,mBuilder.build());


                    }else{

                        title_detection.setTextColor(getResources().getColor(R.color.green));
                        title_detection.setText("il n'y a pas d'intrus");
                        detection_image.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.green));


                    }



                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Failed to read value

                }
            });
        } catch(Exception e)
        {


        }



        //switch components hooks
//        switch_btn1 = v.findViewById(R.id.switch_btn1);
        switch_txt1 = v.findViewById(R.id.switch_txt1);
        switch_btn2 = v.findViewById(R.id.switch_btn2);
        switch_txt2 = v.findViewById(R.id.switch_txt2);
//        switch_btn3 = v.findViewById(R.id.switch_btn3);
//        switch_txt3 = v.findViewById(R.id.switch_txt3);


//        //switch image hook
//        lampe_im = v.findViewById(R.id.lampe_im);
//        aircond_im = v.findViewById(R.id.aircond_im);
        window_im = v.findViewById(R.id.window_im);

        //switch circles layout
//        lampe_circle = v.findViewById(R.id.lampe_circle);
//        window_circle = v.findViewById(R.id.window_circle);
//        aircond_circle = v.findViewById(R.id.aircond_circle);



//        v.findViewById(R.id.add_new_device).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                v.findViewById(R.id.add_new_device).startAnimation(AnimationUtils.loadAnimation(v.getContext(), R.anim.shake_animation));
//            }
//        });



//        switch_btn1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//
//                v.findViewById(R.id.card1).startAnimation(AnimationUtils.loadAnimation(v.getContext(), R.anim.image_anim)); // starts animation
//
//
//                if(switch_btn1.isChecked()){switch_txt1.setText("ON");
//                    lampe_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.green));
////                    lampe_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle_vert));
//                    switch_txt1.setTextColor(getResources().getColor(R.color.green));
//
//
//                    //save state
//                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("switches_state_bedroom", Context.MODE_PRIVATE).edit();
//                    editor.putBoolean("switch1", true);
//                    editor.apply();
//
//                }
//                else{switch_txt1.setText("OFF");
//                    lampe_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.red));
////                    lampe_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle));
//                    switch_txt1.setTextColor(getResources().getColor(R.color.red));
//
//                    //save state
//                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("switches_state_bedroom", Context.MODE_PRIVATE).edit();
//                    editor.putBoolean("switch1", false);
//                    editor.apply();
//
//                }
//            }});


        switch_btn2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                v.findViewById(R.id.card1).startAnimation(AnimationUtils.loadAnimation(v.getContext(), R.anim.image_anim)); // starts animation

                if(switch_btn2.isChecked()){switch_txt2.setText("Fermee");
                    window_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.red));
//                    window_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle_vert));
                    switch_txt2.setTextColor(getResources().getColor(R.color.red));


                    final Publish publish1 = new Publish("doorState/Closed", "1", 0, true);
                    publish(publish1, new IMqttActionListener() {
                        @Override
                        public void onSuccess(IMqttToken asyncActionToken) {
//                        mPublishList.add(0, publish);
//                        mAdapter.notifyItemInserted(0);
                        }

                        @Override
                        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
//                            Toast.makeText(fragmentActivity, "Failed to publish", Toast.LENGTH_SHORT).show();

                        }
                    });



                    final Publish publish2 = new Publish("doorState/Opened", "0", 0, true);
                    publish(publish2, new IMqttActionListener() {
                        @Override
                        public void onSuccess(IMqttToken asyncActionToken) {
//                        mPublishList.add(0, publish);
//                        mAdapter.notifyItemInserted(0);
                        }

                        @Override
                        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
//                            Toast.makeText(fragmentActivity, "Failed to publish", Toast.LENGTH_SHORT).show();

                        }
                    });




                    //save state
                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("switches_state_bedroom", Context.MODE_PRIVATE).edit();
                    editor.putBoolean("switch2", true);
                    editor.apply();

                }
                else{switch_txt2.setText("Ouverte");
                    window_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.green));
//                    window_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle));
                    switch_txt2.setTextColor(getResources().getColor(R.color.green));



                    final Publish publish1 = new Publish("doorState/Opened", "1", 0, true);
                    publish(publish1, new IMqttActionListener() {
                        @Override
                        public void onSuccess(IMqttToken asyncActionToken) {
//                        mPublishList.add(0, publish);
//                        mAdapter.notifyItemInserted(0);
                        }

                        @Override
                        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                            Toast.makeText(getContext(), "Failed to publish", Toast.LENGTH_SHORT).show();

                        }
                    });





                    final Publish publish2 = new Publish("doorState/Closed", "0", 0, true);
                    publish(publish2, new IMqttActionListener() {
                        @Override
                        public void onSuccess(IMqttToken asyncActionToken) {
//                        mPublishList.add(0, publish);
//                        mAdapter.notifyItemInserted(0);
                        }

                        @Override
                        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
//                            Toast.makeText(fragmentActivity, "Failed to publish", Toast.LENGTH_SHORT).show();

                        }
                    });

                    //save state
                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("switches_state_bedroom", Context.MODE_PRIVATE).edit();
                    editor.putBoolean("switch2", false);
                    editor.apply();

                }
            }});

//
//        switch_btn3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//
//                v.findViewById(R.id.card3).startAnimation(AnimationUtils.loadAnimation(v.getContext(), R.anim.image_anim)); // starts animation
//
//                if(switch_btn3.isChecked()){switch_txt3.setText("ON");
//                    aircond_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.green));
////                    aircond_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle_vert));
//                    switch_txt3.setTextColor(getResources().getColor(R.color.green));
//
//
//                    //save state
//                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("switches_state_bedroom", Context.MODE_PRIVATE).edit();
//                    editor.putBoolean("switch3", true);
//                    editor.apply();
//
//                }
//                else{switch_txt3.setText("OFF");
//                    aircond_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.red));
////                    aircond_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle));
//                    switch_txt3.setTextColor(getResources().getColor(R.color.red));
//
//                    //save state
//                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("switches_state_bedroom", Context.MODE_PRIVATE).edit();
//                    editor.putBoolean("switch3", false);
//                    editor.apply();
//
//                }
//            }});
//
//



        //check buttons states
        saveSwitchState(v);

        return v;
    }





    //check buttons states
    public void saveSwitchState(View v) {

        //initialise sharedPreference state
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("switches_state_bedroom", Context.MODE_PRIVATE);

//        if (sharedPreferences.getBoolean("switch1",false)) {
//
//            switch_btn1.setChecked(true);
//            lampe_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.green));
////            lampe_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle_vert));
//            switch_txt1.setTextColor(getResources().getColor(R.color.green));
//
//
//        } else {
//
//            switch_btn1.setChecked(false);
//            lampe_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.red));
////            lampe_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle));
//            switch_txt1.setTextColor(getResources().getColor(R.color.red));
//
//        }


        if (sharedPreferences.getBoolean("switch2", false)) {

            switch_btn2.setChecked(true);
            window_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.red));
//            window_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle_vert));
            switch_txt2.setTextColor(getResources().getColor(R.color.red));


        } else {

            switch_btn2.setChecked(false);
            window_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.green));
//            window_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle));
            switch_txt2.setTextColor(getResources().getColor(R.color.green));

        }

//
//        if (sharedPreferences.getBoolean("switch3", false)) {
//
//            switch_btn3.setChecked(true);
//            aircond_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.green));
////            aircond_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle_vert));
//            switch_txt3.setTextColor(getResources().getColor(R.color.green));
//
//        } else {
//
//            switch_btn3.setChecked(false);
//            aircond_im.setColorFilter(ContextCompat.getColor(v.getContext(),R.color.red));
////            aircond_circle.setBackground(ContextCompat.getDrawable(v.getContext(),R.drawable.device_circle));
//            switch_txt3.setTextColor(getResources().getColor(R.color.red));
//
//        }



    }






    public void connect(Connection connection, IMqttActionListener listener) {
        mClient = connection.getMqttAndroidClient(getContext());
        try {
            mClient.connect(connection.getMqttConnectOptions(), null, listener);
            mClient.setCallback(this);
        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Failed to connect", Toast.LENGTH_SHORT).show();
        }

    }



    public void disconnect() {
        if (notConnected(true)) {
            return;
        }
        try {
            mClient.disconnect();
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }




    public void publish(Publish publish, IMqttActionListener callback) {
        if (notConnected(true)) {
            return;
        }
        try {
            mClient.publish(publish.getTopic(), publish.getPayload().getBytes(), publish.getQos(), publish.isRetained(), null, callback);
        } catch (MqttException e) {
            e.printStackTrace();
//            Toast.makeText(getContext(), "Failed to publish", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean notConnected(boolean showNotify) {
        if (mClient == null || !mClient.isConnected()) {
            if (showNotify) {
//                Toast.makeText(getContext(), "Client is not connected", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return false;
    }


    @Override
    public void connectionLost(Throwable cause) {

    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {

    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }






    @TargetApi(Build.VERSION_CODES.O)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)

    public void show_Notification(){


        Uri sound = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + getContext().getPackageName() + "/" + R.raw.alert);  //Here is FILE_NAME is the name of file that you want to play

        Intent intent=new Intent(getContext(),Bedroom_Frag.class);
        String CHANNEL_ID="MYCHANNEL";
        NotificationChannel notificationChannel=new NotificationChannel(CHANNEL_ID,"name",NotificationManager.IMPORTANCE_HIGH);
        PendingIntent pendingIntent=PendingIntent.getActivity(getContext(),1,intent,0);
        Notification notification=new Notification.Builder(getContext(),CHANNEL_ID)
                .setContentText("un intrut est ditectee")
                .setContentTitle("ALERT :")
                .setContentIntent(pendingIntent)
                .addAction(R.drawable.person,"Alerte de securite",pendingIntent)
                .setChannelId(CHANNEL_ID)
                .setSound(sound)
//                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
                .setDefaults(Notification.FLAG_ONLY_ALERT_ONCE|Notification.DEFAULT_VIBRATE)
                .setColor(25500)
                .setSmallIcon(R.drawable.person)
                .build();




//        .setDefaults(Notification.FLAG_ONLY_ALERT_ONCE);
//        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//        MediaPlayer mp= MediaPlayer.create(contexto, R.raw.your_sound);
        //                                .setDefaults(Notification.DEFAULT_LIGHTS| Notification.DEFAULT_SOUND)

//                        mBuilder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));

        NotificationManager notificationManager=(NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
        MediaPlayer mp= MediaPlayer.create(getContext(),R.raw.alert);
        mp.start();
        notificationManager.createNotificationChannel(notificationChannel);
        notificationManager.notify(1,notification);



    }


}  //class end